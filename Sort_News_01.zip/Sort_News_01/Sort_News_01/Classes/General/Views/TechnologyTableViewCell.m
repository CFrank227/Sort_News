//
//  TechnologyTableViewCell.m
//  Sort_News_01
//
//  Created by lanou3g on 15/7/10.
//  Copyright (c) 2015年 Frank. All rights reserved.
//

#import "TechnologyTableViewCell.h"

@implementation TechnologyTableViewCell









- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
