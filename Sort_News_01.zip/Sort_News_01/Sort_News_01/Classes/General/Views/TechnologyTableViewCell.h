//
//  TechnologyTableViewCell.h
//  Sort_News_01
//
//  Created by lanou3g on 15/7/10.
//  Copyright (c) 2015年 Frank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TechnologyTableViewCell : UITableViewCell

@property (nonatomic, retain) UILabel *newsTitleLabel;
@property (nonatomic, retain) UILabel *newsDetaiLabel;


@end
