//
//  GroomTableViewController.h
//  Sort_News_01
//
//  Created by lanou3g on 15/7/9.
//  Copyright (c) 2015年 Frank. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GroomTableViewController : UITableViewController

@end
