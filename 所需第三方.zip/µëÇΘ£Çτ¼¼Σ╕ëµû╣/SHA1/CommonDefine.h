//
//  CommonDefine.h
//  Tuantuangou
//
//  Created by Duke on 13-6-3.
//  Copyright (c) 2013年 Duke. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonDefine : NSObject

#define kAPP_KEY  @"42960815" //@"955330803"
#define kAPP_SECRET @"bfcd4f05204b4ac7b1d68a711d077b9c" //@"5e7e17c799f2467494218d2af21688cf"
#define kBASE_SERVER_URL @"http://api.dianping.com"

@end
